package searchLib;

import java.util.HashMap;
import java.util.List;

public interface Searchable<T> {
	State<T> getInitialState();
	State<T> getGoalState();
//	List<State<T>> getAllPossibleStates(State<T> state);
	HashMap<Action, State<T>> getAllPossibleMoves(State<T> state);
}
