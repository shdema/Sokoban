package db;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity(name = "Scoreboard")
public class Score {

	@EmbeddedId
	private ScorePK key;
	@Column(name = "Steps")
	private int steps;
	@Column(name = "Time")
	private String time;

	public Score() {
	}

	public ScorePK getKey() {
		return key;
	}

	public void setKey(ScorePK key) {
		this.key = key;
	}

	public int getSteps() {
		return steps;
	}

	public void setSteps(int steps) {
		this.steps = steps;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
