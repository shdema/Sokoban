package stripsLib;

import java.util.PriorityQueue;

public interface Plannable {

	Clause getGoal(Clause kb);
	Clause getKnowledgebase();
	PriorityQueue<Action> getSatisfyingActions(Predicate top);
	Action getSatisfyingAction(Predicate top);
	
}
