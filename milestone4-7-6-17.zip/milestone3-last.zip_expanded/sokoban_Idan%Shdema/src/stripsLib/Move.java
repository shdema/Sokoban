package stripsLib;

import java.util.LinkedList;

import searchLib.SearchLibAction;

public class Move extends Action {

	private LinkedList<SearchLibAction> actions;
	
	public Move(String type, String id, String value) {
		super(type, id, value);
		// TODO Auto-generated constructor stub
	}
	
	
	
		
	

}
