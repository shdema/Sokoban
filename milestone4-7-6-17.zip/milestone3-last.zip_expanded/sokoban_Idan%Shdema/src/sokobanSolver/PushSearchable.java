package sokobanSolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import model.data.Position;
import searchLib.SearchLibAction;
import searchLib.State;

public class PushSearchable extends CommonSokobanSearchable {

	int sokX,sokY;
	
	public PushSearchable(char[][] sb, int initX, int initY, int goalX, int goalY, int sokX, int sokY) {
		super(sb, initX, initY, goalX, goalY);
		this.sokX = sokX;
		this.sokY = sokY;
	}

	//TODO: check that sokoban can reach the box
	@Override
	public HashMap<SearchLibAction, State<Position>> getAllPossibleMoves(State<Position> state) {
		int x = state.getState().getX();
		int y = state.getState().getY();
		Position r = new Position(x,y+1);
		Position l = new Position(x,y-1);		
		Position u = new Position(x-1,y);
		Position d = new Position(x+1,y);
		
		State<Position> sr = new State<Position>(r);
		State<Position> sl = new State<Position>(l);
		State<Position> su = new State<Position>(u);
		State<Position> sd = new State<Position>(d);
		//each state holds the action that led to its state
		sr.setAction(new SearchLibAction("Move right"));
		sl.setAction(new SearchLibAction("Move left"));
		su.setAction(new SearchLibAction("Move up"));
		sd.setAction(new SearchLibAction("Move down"));
		
		Position boxP = initState.getState();
		
		if (inSignBoard(r) && inSignBoard(l))
		{
			if(isClear(r,boxP)&&isClear(l,boxP))
			{
				map.put(sr.getAction(), sr);
				map.put(sl.getAction(), sl);
				System.out.println(sr.getState().getX()+","+sr.getState().getY()+" "+":"+" "+sl.getState().getX()+","+sl.getState().getY());
			}
		}
		if (inSignBoard(u) && inSignBoard(d))
		{
			if(isClear(u,boxP)&&isClear(d,boxP))
			{
				map.put(su.getAction(), su);
				map.put(sd.getAction(), sd);
				System.out.println(su.getState().getX()+","+su.getState().getY()+" "+":"+" "+sd.getState().getX()+","+sd.getState().getY());
			}
		}
		return map;
	}
//	public ArrayList<State<Position>> getAllPossibleMoves(State<Position> state) {
//		int x = state.getState().getX();
//		int y = state.getState().getY();
//		Position r = new Position(x,y+1);
//		Position l = new Position(x,y-1);		
//		Position u = new Position(x-1,y);
//		Position d = new Position(x+1,y);
//		
//		State<Position> sr = new State<Position>(r);
//		State<Position> sl = new State<Position>(l);
//		State<Position> su = new State<Position>(u);
//		State<Position> sd = new State<Position>(d);
//		
//		sr.setAction(new SearchLibAction("Move right"));
//		sl.setAction(new SearchLibAction("Move left"));
//		su.setAction(new SearchLibAction("Move up"));
//		sd.setAction(new SearchLibAction("Move down"));
//		
//		if (inSignBoard(r) && inSignBoard(l))
//		{
//			if(isClear(r)&&isClear(l))
//			{
//				list.add(sr);
//				list.add(sl);
//			}
//		}
//		if (inSignBoard(u) && inSignBoard(d))
//		{
//			if(isClear(u)&&isClear(d))
//			{
//				list.add(su);
//				list.add(sd);
//			}
//		}
//		return list;
//	}
}
