package sokobanSolver;

import model.data.Position;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import searchLib.SearchLibAction;
import searchLib.Searchable;
import searchLib.State;

public abstract class CommonSokobanSearchable implements Searchable<Position> {
	char[][] signB;
	State<Position> initState;
	State<Position> goalState;
	HashMap<SearchLibAction, State<Position>> map;
//	ArrayList<State<Position>> list;
	
	public CommonSokobanSearchable(char[][] sb, int initX, int initY, int goalX, int goalY){
		signB=sb;
		initState = new State<Position>(new Position(initX,initY));
		goalState = new State<Position>(new Position(goalX,goalY));
		map = new HashMap<>();
//		list = new ArrayList<>();
	}
	
	
	public boolean inSignBoard(Position p)
	{
		int x = p.getX();
		int y = p.getY();
		if (x<signB.length && x>=0 && y<signB[0].length && y>=0)
			return true;
		return false;
	}
	
	@Override
	public State<Position> getInitialState() {
		return initState;
	}
	
	@Override
	public State<Position> getGoalState() {
		return goalState;
	}
	
	@Override
	public abstract HashMap<SearchLibAction, State<Position>> getAllPossibleMoves(State<Position> state);
//	public abstract ArrayList<State<Position>> getAllPossibleMoves(State<Position> state);

	boolean isClear(Position p, Position boxP){
		if (signB[p.getX()][p.getY()]!='#')
		{
			if (signB[p.getX()][p.getY()]!='@')
				return true;
			if (signB[p.getX()][p.getY()]=='@' && p.equals(boxP))
				return true;
		}
		return false;
	}
}
