package controller;

import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;

import controller.server.SokobanServer;
import model.Model;
import view.DBView;
import view.ScoreboardWindowController;


public class DBController implements Observer {
	private Model model; // reference facade to model
	private DBView scoreView; // 
	private DBView detailsView; //
	private Controller controller; // reference to general Controller class
	private SokobanServer server;
	
	private boolean serverOn = false; // a flag to see if we run on server or locally

	public DBController(Model model, DBView details, DBView score) {
		this.model = model;
		this.scoreView = score;
		this.detailsView = details;
	}

	
	@Override
	public void update(Observable obs, Object arg) {
		@SuppressWarnings("unchecked")
		LinkedList<String> params = (LinkedList<String>) arg; // O(1) solution
		if (obs == model) {
			
			if(params.get(0).equals("scoreList"))
			{
				scoreView.setScoreList(model.getScoreList());
			}
//			else if(params.get(0).equals("scoreListUser"))
//			{
//				scoreView.setScoreList(model.getScoreList("User"));
//			}
//			else if(params.get(0).equals("scoreListLevel"))
//			{
//				scoreView.setScoreList(model.getScoreList("Level"));
//			}
		}

		if (obs == detailsView) { // if view updates the controller
				if ((params.get(0).equals("Details"))) // got user details from view
				{
					model.userDetails(params); // pass model the user details
					model.levelDetails(model.getLevel());
				}
		}
		
		else if (obs == scoreView)
		{
			if (params.get(0).equals("topScores"))
			{
				model.topScores();
			}
			else if(params.get(0).equals("topScoresUser"))
			{
				scoreView.setScoreList(model.getScoreListUser(params.get(1)));
			}
			else if(params.get(0).equals("topScoresLevel"))
			{
				scoreView.setScoreList(model.getScoreListLevel(params.get(1)));
			}
		}

//				
//				else if(params.get(0).equals("topScoresUser"))
//				{
//					view.setScoreList(model.getScoreListUser(params.get(1)));
//				}
//				else if(params.get(0).equals("topScoresLevel"))
//				{
//					view.setScoreList(model.getScoreListLevel(params.get(1)));
//				}
				
				
//				else if (params.get(0).equals("topScoresUser"))
//				{
//					model.topScoresUser(params.get(1));
//				}
//				else if (params.get(0).equals("topScoresLevel"))
//				{
//					model.topScoresLevel(params.get(1));
//				}

//				else {
//					CommandFactory cf = new CommandFactory(params, model, view, controller);
//					Command c = cf.createCommand();
//					if (c != null) // c exists
//					{
//						controller.insertCommand(c);
//					} else
//						view.displayMessage("noCommand");
//				}
//			} else // SERVER
//			{
//				CommandFactory cf = new CommandFactory(params, model, view, controller);
//				Command c = cf.createCommand();
//				if (c != null) // c exists
//				{
//							controller.insertCommand(c); 
//					
//				}
//				else 
//				{
//					server.getCh().feedback("noCommand");
//				}
//			}


//	public HashMap<String, String> mapKeyCodes(File f) {
//
//		Scanner s;
//
//		try {
//			HashMap<String, String> keyMap = new HashMap<String, String>();
//
//			s = new Scanner(f);
//
//			while (s.hasNextLine()) {
//				String str = s.nextLine();
//				String[] keyVal = str.split(":");
//				keyMap.put(keyVal[0], keyVal[1]);
//			}
//			s.close();
//			return keyMap;
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//
//		return null;
//
//	}

//	public void startServer(int port) throws Exception {
//		server = new SokobanServer(port);
//		server.start();
//	}
//
//	public void stopServer() {
//		server.stop();
//	}
//
//	// gets and sets
//	public Model getModel() {
//		return model;
//	}
//
//	public void setModel(Model model) {
//		this.model = model;
//	}
//
//	public View getView() {
//		return view;
//	}
//
//	public void setView(View view) {
//		this.view = view;
//	}
//
//	public Controller getController() {
//		return controller;
//	}
//
//	public void setController(Controller controller) {
//		this.controller = controller;
//	}
//
//	public void setServerOn() {
//		serverOn = true;
//	}
//
//	public SokobanServer getServer() {
//		return server;
//	}

}
}
