package view;

import java.util.LinkedList;

import model.db.Score;

public interface DBView {

	void setScoreList(LinkedList<Score> scoreList);

}
