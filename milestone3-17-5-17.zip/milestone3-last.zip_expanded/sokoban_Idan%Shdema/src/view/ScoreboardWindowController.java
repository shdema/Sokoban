package view;

import java.net.URL;
import java.util.LinkedList;
import java.util.Observable;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.db.Score;

public class ScoreboardWindowController extends Observable implements Initializable, DBView{

//	private Pane scorePane;
	private Stage primaryStage;
	LinkedList<Score> scoreList;
	ObservableList<Score> obsList;

	
	@FXML
	TextField userID;
	
	@FXML
	TextField levelName;
	
	@FXML
	TableView<Score> table;
	
	@FXML
	TableColumn<Score, Integer> user;
	
	@FXML
	TableColumn<Score, String> level;
	
	@FXML
	TableColumn<Score, Integer> steps;
	
	@FXML
	TableColumn<Score, Integer> time;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		obsList = FXCollections.observableArrayList();
		
//		TableColumn<Score, Integer> userID = new TableColumn<>("UserID");
//		TableColumn<Score, String> levelID = new TableColumn<>("Level name");
//		TableColumn<Score, Integer> steps = new TableColumn<>("Steps");
//		TableColumn<Score, Integer> time = new TableColumn<>("Time");
//
		user.setCellValueFactory(new PropertyValueFactory<Score, Integer>("UserID"));
		level.setCellValueFactory(new PropertyValueFactory<Score, String>("LevelID"));
		steps.setCellValueFactory(new PropertyValueFactory<Score, Integer>("Steps"));
		time.setCellValueFactory(new PropertyValueFactory<Score, Integer>("Time"));

		LinkedList<String> params = new LinkedList<String>();
		params.add("topScores");
		setChanged();
		notifyObservers(params);
		

//		table.getColumns().addAll(userID,levelID,steps,time);
	}
	
	public void searchID()
	{
		LinkedList<String> params = new LinkedList<String>();
		params.add("topScoresUser");
		params.add(userID.getText());
		setChanged();
		notifyObservers(params);
	}
	
	public void searchLevel()
	{
		LinkedList<String> params = new LinkedList<String>();
		params.add("topScoresLevel");
		params.add(levelName.getText());
		setChanged();
		notifyObservers(params);
	}

	public void setScoreList(LinkedList<Score> arg) {
		scoreList = arg;
		if (scoreList!=null)
		{
			for (int i = 0; i < scoreList.size(); i++) {
				obsList.add(scoreList.get(i));
			}
			table.setItems(obsList);
		}
	}
	
	
	public Stage getPrimaryStage() {
		return primaryStage;
	}
	
	
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}
	
}
