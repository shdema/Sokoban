package model.db;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Manager {
	private static SessionFactory factory;
	private User user;

	public Manager() {
		Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
		Configuration configuration = new Configuration();
		configuration.configure();
		factory = configuration.buildSessionFactory();
	}

	public int addUser(String fName, String lName, int id) {
		user = new User(fName, lName, id);
		Transaction tx = null;
		int userID = 0;
		List<User> users = null;
		Session session = factory.openSession();
		try {
			tx = session.beginTransaction();
			
			//if the user exists (duplicate id)
			
			Query<User> q = session.createQuery("from Users where ID like ?");
			q.setParameter(0, id);
			users = q.list();
			
			if (users.size() > 0)
			{
//				user
			}
			else
			{
				userID = (int) session.save(user);
				tx.commit();
			}
			
		} 
		catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} 
		finally {
			session.close();
		}
		return userID;
	}

	public void addLevel(commons.Level l) {
		Transaction tx1 = null;
		List<Level> levels = null;
		Session session = factory.openSession();
		try {
			tx1 = session.beginTransaction();			
			//if the user exists (duplicate id)
			
			Query<Level> q = session.createQuery("from Levels where Name like ?");
			q.setParameter(0, l.getName());
			levels = q.list();
			
			if (levels.size() > 0)
			{
//				user
			}
			else
			{
				session.save(l);
				tx1.commit();
			}
		} catch (HibernateException e) {
			if (tx1 != null)
				tx1.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	// adds the current level to the db
	public void addScore(User user, commons.Level l) {
		Score s = new Score(user.getId(), l.getName(), l.getSteps(), l.getMyTimer().toString());
		Transaction tx2 = null;
		List<Score> scores = null;
//		int scoreID = 0;
		Session scoreSession = factory.openSession();
		try {
			tx2 = scoreSession.beginTransaction();

			
			Query<Score> q = scoreSession.createQuery("from Scoreboard where UserID like ? and LevelID like ?");
			q.setParameter(0, user.getId());
			q.setParameter(1, l.getName());
			scores = q.list();
			
			if (scores.size()>0)
			{
				//display msg: "Score already exists. Broke record/not" update if better
			}
			
			else
			{			
				scoreSession.save(s);
				tx2.commit();
			}
			
		} catch (HibernateException e) {
			if (tx2 != null)
				tx2.rollback();
			e.printStackTrace();
		} finally {
			scoreSession.close();
		}
//		return scoreID;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	// Method to print all employees
	// public void printUsers() {
	// Session session = factory.openSession();
	// try {
	// @SuppressWarnings("unchecked")
	// Query<User> query = session.createQuery("from Users");
	// List<User> list = query.list();
	// for (User e : list) {
	// System.out.println(e);
	// }
	// } catch (HibernateException e) {
	// e.printStackTrace();
	// } finally {
	// session.close();
	// }
	// }

	// Method to print all employees whose names start with specified prefix

	// private static void printEmployeesWhoseNameStartsWith(String prefix) {
	// Session session = factory.openSession();
	// Query query = session.createQuery("from Employees E where E.first_name
	// LIKE :prefix");
	// query.setParameter("prefix", prefix + "%");
	// List<Employee> list = query.list();
	// for (Employee e : list) {
	// System.out.println(e);
	// }
	// session.close();
	// }
	//
	// // Method to update a salary for an employee
	// private static void updateSalary(int empId, double salary) {
	// Session session = factory.openSession();
	// Transaction tx = null;
	// try {
	// tx = session.beginTransaction();
	// Employee emp = session.get(Employee.class, empId);
	// emp.setSalary(salary);
	// session.update(emp);
	// tx.commit();
	// } catch (HibernateException e) {
	// if (tx != null)
	// tx.rollback();
	// e.printStackTrace();
	// } finally {
	// session.close();
	// }
	// }
	//
	// // Method to delete an employee
	// private static void deleteEmployee(int empId) {
	// Session session = factory.openSession();
	// Transaction tx = null;
	// try {
	// tx = session.beginTransaction();
	// Employee emp = session.get(Employee.class, empId);
	// session.delete(emp);
	// tx.commit();
	// } catch (HibernateException e) {
	// if (tx != null)
	// tx.rollback();
	// e.printStackTrace();
	// } finally {
	// session.close();
	// }
	// }
}
