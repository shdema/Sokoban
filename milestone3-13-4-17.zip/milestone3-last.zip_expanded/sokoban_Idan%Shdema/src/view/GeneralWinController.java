package view;

import java.util.HashMap;
import java.util.Observable;

import javafx.stage.Stage;

public abstract class GeneralWinController extends Observable implements View {

	public void setKeyMap(HashMap<String, String> mapKeyCodes) {
		// TODO Auto-generated method stub
		
	}

	public void setStage(Stage primaryStage) {
		// TODO Auto-generated method stub
		
	}

	public void exitGame() {
		// TODO Auto-generated method stub
		
	}

}
