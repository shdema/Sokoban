package view;

import java.net.URL;
import java.util.Observable;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

public class ScoreboardWindowController extends Observable implements Initializable, DBView{

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
