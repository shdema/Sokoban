package view;

import java.net.URL;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;

import commons.Level;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.db.Score;

public class DetailsWindowController extends Observable implements Initializable, DBView{

	private Pane scorePane;
	private Stage primaryStage;
	
	@FXML
	TextField fName;
	
	@FXML
	TextField lName;
	
	@FXML
	TextField Iduser;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub		
	}

	public void setDetails(){
		LinkedList<String> params = new LinkedList<String>();
		params.add("Details"); // so the controller knows it's the user details 
		params.add(fName.getText());
		params.add(lName.getText());
		params.add(Iduser.getText()); // casting to int when receive
		setChanged();
		notifyObservers(params);
		Platform.runLater(new Runnable() { // move to JavaFX thread

			@Override
			public void run() {
				Scene scene = new Scene(scorePane, 600, 600);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.show();
			}
		});
	}

	public void setScorePane(Pane scorePane) {
		this.scorePane=scorePane;		
	}
	

}
