package view;

public interface DBView {

}
