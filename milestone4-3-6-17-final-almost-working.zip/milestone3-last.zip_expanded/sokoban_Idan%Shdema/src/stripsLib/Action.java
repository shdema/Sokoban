package stripsLib;

public class Action extends Predicate{

	protected Clause preconditions,effects;

	public Action(String type, String id, String value) {
		super(type, id, value);
		// TODO Auto-generated constructor stub
	}

	public Clause getPreconditions() {
		return preconditions;
	}

	public Clause getEffects() {
		return effects;
	}

	public void setPreconditions(Clause preconditions) {
		this.preconditions = preconditions;
	}

	public void setEffects(Clause effects) {
		this.effects = effects;
	}
	
	
}
