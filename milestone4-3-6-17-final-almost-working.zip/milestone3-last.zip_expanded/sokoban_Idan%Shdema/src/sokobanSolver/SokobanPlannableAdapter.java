package sokobanSolver;

import java.util.Comparator;
import java.util.PriorityQueue;

import model.data.Position;
import searchLib.BFS;
import searchLib.SearchLibAction;
import searchLib.Searcher;
import searchLib.Solution;
import stripsLib.Action;
import stripsLib.Clause;
import stripsLib.Plannable;
import stripsLib.Predicate;

public class SokobanPlannableAdapter implements Plannable {

	char[][] signB;
	Clause goal;
	Clause kb;
	
	public SokobanPlannableAdapter(char[][] signboard){
		signB = signboard;
		goal = new Clause(null);
		kb = new Clause(null);
	}
	
	@Override
	public Clause getGoal(Clause kb) {
		for(Predicate p : kb.getPredicates()){
			if(p.getType().startsWith("star")){
				goal.add(new Predicate("boxAt", "?", p.getValue()));
			}
		}
		return goal;
	}
		

	@Override
	public Clause getKnowledgebase() {
		int boxCount=0;
		int starCount=0;
		for(int i=0;i<signB.length;i++){
			for(int j=0;j<signB[i].length;j++){
				switch(signB[i][j]){
				case '#':kb.add(new Predicate("wallAt", "", i+","+j));break;
				case ' ':kb.add(new Predicate("clearAt", "", i+","+j));break;
				case 'A':kb.add(new Predicate("sokobanAt", "", i+","+j));break;
				case '@':boxCount++;kb.add(new Predicate("boxAt", "b"+boxCount, i+","+j));break;
				case 'o':starCount++;kb.add(new Predicate("starAt", "t"+starCount, i+","+j));break;
				}
			}
		}
		return kb;
	}

	@Override
	public PriorityQueue<Action> getSatisfyingActions(Predicate top) {
		PriorityQueue<Action> queue = new PriorityQueue<>(4,new Comparator<Action>(){

			@Override
			public int compare(Action a1, Action a2) {
				//TODO: return the action with the LESS satisfied preconditions so the MOST will push last to the stack
				return (kb.numOfSatisfied(a1.getPreconditions()) - kb.numOfSatisfied(a2.getPreconditions()));
			}});
		
		//the position we want to go to
		int topX=getPosition(top.getValue()).getX();
		int topY=getPosition(top.getValue()).getY();
		//the position of the box we want to push
		int boxX=getPosition(kb.getBoxPos(top.getId())).getX();
		int boxY=getPosition(kb.getBoxPos(top.getId())).getY();
		//the position of sokoban character at the moment
		int sokX=getPosition(kb.getSokobanPos()).getX();
		int sokY=getPosition(kb.getSokobanPos()).getY();
		switch (top.getType()) {
		case "sokobanAt":
			//TODO: ask Roi when step and when move
			if (sokX-1==topX||sokX+1==topX||sokY-1==topY||sokY+1==topY){
				Action stepAction = new Action("Step", "", kb.getSokobanPos() + ',' + top.getValue());
				stepAction.setPreconditions(new Clause(new Predicate("clearAt", "", topX + "," + topY)));			
				stepAction.setEffects(new Clause(new Predicate("sokobanAt", "", topX + "," + topY),new Predicate("clearAt", "", sokX + "," + sokY)));
				queue.add(stepAction);
				break;
			}
			else {
				Searcher<Position> bfs = new BFS<Position>();
				Solution sol = bfs.search(new MoveSearchable(signB, sokX, sokY, topX, topY));
				if (sol!=null)
				{
					System.out.println(sol);
					Action moveAction = new Action("Move", "", kb.getSokobanPos() + ',' + top.getValue());
					moveAction.setPreconditions(new Clause(new Predicate("clearAt", "", topX + "," + topY)));
					moveAction.setEffects(new Clause(new Predicate("sokobanAt", "", topX + "," + topY), new Predicate("clearAt", "", sokX + "," + sokY)));
					queue.add(moveAction);					
				}
				else {
					//there is no path
					//get back to where you came from
				}
				break;			
			}
		case "boxAt":
			Searcher<Position> bfs = new BFS<Position>();
			Solution pushSol = bfs.search(new PushSearchable(signB, boxX, boxY, topX, topY, sokX, sokY));
			if (pushSol!=null)
			{
				String dir = pushSol.getActions().get(0).getName();
				Solution moveSol = null;
				switch (dir) {
				case "Move right":
					moveSol = bfs.search(new MoveSearchable(signB, sokX, sokY, boxX-1, boxY));
					break;
				case "Move left":
					moveSol = bfs.search(new MoveSearchable(signB, sokX, sokY, boxX+1, boxY));
					break;
				case "Move up":
					moveSol = bfs.search(new MoveSearchable(signB, sokX, sokY, boxX, boxY+1));
					break;
				case "Move down":
					moveSol = bfs.search(new MoveSearchable(signB, sokX, sokY, boxX, boxY-1));
					break;
				}
				if (moveSol != null)
				{
					System.out.println(moveSol);
					System.out.println(pushSol);
					
					//TODO: check if pushing boxes is only to targets
					Action pushAction = new Action("Push", top.getId() , kb.getBoxPos(top.getId()) + ',' + top.getValue());
					pushAction.setPreconditions(new Clause(new Predicate("sokobanAt", "", /*one of the sides of this box*/""), new Predicate("path", "",boxX + "," + boxY + ":" + topX + "," + topY)));
					pushAction.setEffects(new Clause(new Predicate("boxAt", "", topX + "," + topY), new Predicate("sokobanAt", "", /*formerPlaceOfBox-X*/"" + "," + /*formerPlaceOfBox-Y*/""), new Predicate("clearAt", "", sokX + "," + sokY), new Predicate("clearAt", "", boxX + "," + boxY)));
					queue.add(pushAction); //add push to the stack first so it will be popped after move 
					
					Action moveAction = new Action("Move", "", kb.getSokobanPos() + ',' + top.getValue());
					moveAction.setPreconditions(new Clause(new Predicate("path", "",sokX + "," + sokY + ":" + topX + "," + topY)));
					moveAction.setEffects(new Clause(new Predicate("sokobanAt", "", topX + "," + topY), new Predicate("clearAt", "", sokX + "," + sokY)));
					queue.add(moveAction);
					
				}
				else { //moveSol is null - sokoban can't reach the box! :(
					//TODO: switch target
				}
			}
			else { //pushSol is null - there is no path from the box to the star
				//there is no path
				//TODO: switch target
			}
			break;			

		}		
		return queue;
	}

	@Override
	public Action getSatisfyingAction(Predicate top) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private Position getPosition(String pos){
		int index =pos.indexOf(",");
		int x= Integer.parseInt(pos.substring(1,index));
		int y= Integer.parseInt(pos.substring(index,pos.length()-1));
		return new Position(x,y);
	}

}
