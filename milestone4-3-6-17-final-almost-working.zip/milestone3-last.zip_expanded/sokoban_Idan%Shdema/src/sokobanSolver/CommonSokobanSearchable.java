package sokobanSolver;

import model.data.Position;
import java.util.HashMap;

import searchLib.SearchLibAction;
import searchLib.Searchable;
import searchLib.State;

public abstract class CommonSokobanSearchable implements Searchable<Position> {
	char[][] signB;
	State<Position> initState;
	State<Position> goalState;
	HashMap<SearchLibAction, State<Position>> map;
	
	public CommonSokobanSearchable(char[][] sb, int initX, int initY, int goalX, int goalY){
		signB=sb;
		initState = new State<Position>(new Position(initX,initY));
		goalState = new State<Position>(new Position(goalX,goalY));
		map = new HashMap<>();
	}
	
	
	public boolean inSignBoard(Position p)
	{
		int x = p.getX();
		int y = p.getY();
		if (x<signB.length && x>=0 && y<signB[0].length && y>=0)
			return true;
		return false;
	}
	
	@Override
	public State<Position> getInitialState() {
		return initState;
	}
	
	@Override
	public State<Position> getGoalState() {
		return goalState;
	}
	
	@Override
	public abstract HashMap<SearchLibAction, State<Position>> getAllPossibleMoves(State<Position> state);

	boolean isClear(Position p){
		if(signB[p.getX()][p.getY()]!='@' && signB[p.getX()][p.getY()]!='#')
			return true;
		return false;
	}
}
