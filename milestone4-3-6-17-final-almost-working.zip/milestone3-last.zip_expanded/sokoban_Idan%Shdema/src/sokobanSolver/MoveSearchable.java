package sokobanSolver;

import java.util.HashMap;

import model.data.Position;
import searchLib.SearchLibAction;
import searchLib.State;

public class MoveSearchable extends CommonSokobanSearchable {

	public MoveSearchable(char[][] sb, int initX, int initY, int goalX, int goalY) {
		super(sb, initX, initY, goalX, goalY);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public HashMap<SearchLibAction, State<Position>> getAllPossibleMoves(State<Position> state) {
		int x = state.getState().getX();
		int y = state.getState().getY();
		Position r = new Position(x,y+1);
		Position l = new Position(x,y-1);		
		Position u = new Position(x-1,y);
		Position d = new Position(x+1,y);
		if(inSignBoard(r) && isClear(r))
			map.put(new SearchLibAction("Move right"), new State<Position>(r));
		if(inSignBoard(l) && isClear(l))
			map.put(new SearchLibAction("Move left"), new State<Position>(l));
		if(inSignBoard(u) && isClear(u))
			map.put(new SearchLibAction("Move up"), new State<Position>(u));
		if(inSignBoard(d) && isClear(d))
			map.put(new SearchLibAction("Move down"), new State<Position>(d));
		return map;
	}
}
