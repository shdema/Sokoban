package sokobanSolver;

import java.util.HashMap;

import model.data.Position;
import searchLib.SearchLibAction;
import searchLib.State;

public class PushSearchable extends CommonSokobanSearchable {

	int sokX;
	int sokY;
	
	public PushSearchable(char[][] sb, int initX, int initY, int goalX, int goalY, int sokX, int sokY) {
		super(sb, initX, initY, goalX, goalY);
		this.sokX = sokX;
		this.sokY = sokY;
	}

	//TODO: check that sokoban can reach the box
	@Override
	public HashMap<SearchLibAction, State<Position>> getAllPossibleMoves(State<Position> state) {
		int x = state.getState().getX();
		int y = state.getState().getY();
		Position r = new Position(x,y+1);
		Position l = new Position(x,y-1);		
		Position u = new Position(x-1,y);
		Position d = new Position(x+1,y);
		if (inSignBoard(r) && inSignBoard(l))
		{
			if(isClear(r)&&isClear(l))
				map.put(new SearchLibAction("Move right"), new State<Position>(r));
				map.put(new SearchLibAction("Move left"), new State<Position>(l));
		}
		if (inSignBoard(u) && inSignBoard(d))
		{
			if(isClear(u)&&isClear(d))
				map.put(new SearchLibAction("Move up"), new State<Position>(u));
				map.put(new SearchLibAction("Move down"), new State<Position>(d));
		}
		return map;
	}
}
