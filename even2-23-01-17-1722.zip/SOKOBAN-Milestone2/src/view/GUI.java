package view;

import java.util.Observable;

import model.data.Level;

public class GUI extends Observable implements View {

	@Override
	public void start() {
		// TODO Auto-generated method stub

	}

	@Override
	public void displayMessage(String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void display(Level l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void exit(Level l) {
		// TODO Auto-generated method stub
		
	}

}
