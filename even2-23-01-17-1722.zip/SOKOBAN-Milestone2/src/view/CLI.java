//will be at external client
//at the moment same as MyView

package view;

import java.io.InputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Scanner;

import model.data.Level;

/**
 * The Command Line Interface - responsible for commands, uses CommandFactory according to user input
 * @author ����
 *
 */
public class CLI extends Observable implements View {

	private boolean loaded;
	private String str;
	private Scanner s;
	private String exitStr;
	
	public CLI()
	{
		loaded = false;
		str = "";
		s = new Scanner(System.in);
		exitStr = "Exit";
	}
	
	public CLI(InputStream is)
	{
		loaded = false;
		str = "";
		s = new Scanner(is);
		exitStr = "Exit";
	}
	
	
	@Override
	public void start(){
		new Thread(new Runnable(){
			@Override
			public void run(){
				do 
				{
					System.out.println("Please enter command:");
					str = s.nextLine();
					String[] wordsArr = str.split(" ");
					List<String> params = new LinkedList<String>();
										
					for (String param : wordsArr)
						params.add(param);
					
					if (!params.get(0).equals("Load") && !loaded)
					{
						System.out.println("Load a level please!");
					}
					else
					{
						loaded=true;
						setChanged(); //we know the command is valid
						notifyObservers(params);
					}
				} while (!str.equals(exitStr)); //until the user types 'Exit'
			s.close();
			}
		}).start();
	}
	
	public void displayMessage(String msg){
		System.out.println(msg);
	}

	@Override
	public void display(Level l) {
		PrintCLI pcli = new PrintCLI(); //the print class for CLI
		pcli.print(l);
	}

	@Override
	public void exit(Level l) {
		// TODO Auto-generated method stub		
	}
	
	//sets and gets
	public boolean isLoaded() {
		return loaded;
	}

	public void setLoaded(boolean loaded) {
		this.loaded = loaded;
	}

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public Scanner getS() {
		return s;
	}

	public void setS(Scanner s) {
		this.s = s;
	}
		
}