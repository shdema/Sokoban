package view;

import model.data.Level;

public interface View {

	public void start();
	public void displayMessage(String msg);
	public void display(Level l);
	public void exit(Level l);
}
