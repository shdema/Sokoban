package controller.server;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.List;

public interface ClientHandler {
	void handleClient(BufferedReader inFromClient, PrintWriter outToClient);
	List<String> getParams();
}
