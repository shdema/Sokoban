package controller.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

public class Handler implements ClientHandler {
	
	private List<String> params;
	
	
	@Override
	public void handleClient(BufferedReader inFromClient, PrintWriter outToClient) {
//		CLI cli = new CLI();
//		cli.start();
		
		String str;
		try 
		{
			str = inFromClient.readLine();
			String[] wordsArr = str.split(" ");
			params = new LinkedList<String>();
			for (String param : wordsArr)
				params.add(param);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	//gets and sets
	public List<String> getParams() {
		return params;
	}


	public void setParams(List<String> params) {
		this.params = params;
	}
}
