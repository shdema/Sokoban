//will be abstract class because all of them have to maintain datamembers
package controller.commands;

import java.util.List;

/**
 * Interface for commands
 * @author ����
 *
 */
public abstract class SokobanCommand implements Command {
	protected List<String> params;	
	
	public void setParams(List<String> params){
		this.params = params; 
	}
	
	public abstract void execute();
}
