package boot;

import controller.SokobanController;
import model.MyModel;
import model.data.Level;
import view.CLI;
import view.GUI;

public class Run {

	public static void main(String[] args) {
//		GUI view = new GUI();
		CLI cli = new CLI();
		MyModel model = new MyModel(new Level());
		SokobanController c = new SokobanController(model,cli);
		model.addObserver(c);
		cli.addObserver(c);

		cli.start();
	}
}
