package model;

import java.io.IOException;
import java.util.ListIterator;
import java.util.Observable;

import commons.SignBoard;
import model.data.Box;
import model.data.Character;
import model.data.Level;
import model.data.LevelLoader;
import model.data.LevelSaver;
import model.data.LoaderFactory;
import model.data.MovableItem;
import model.data.Position;
import model.data.SaverFactory;
import model.policy.MySokobanPolicy;

public class MyModel extends Observable implements Model {
	private Level l;
	private char[][] signBoard;

	
	public MyModel(Level l){
		this.l=l;
		this.signBoard = new SignBoard(l).getSignBoard();
	}
	
	private Position moveTo(MovableItem mi, String dir)
	{
		
		Position p=new Position(mi.getPosition().getX(),mi.getPosition().getY());
		if (dir.equals("down"))
		{
			p.setX(mi.getPosition().getX()+1);
		}
		else if (dir.equals("up"))
		{
			p.setX(mi.getPosition().getX()-1);
		}
		else if (dir.equals("left"))
		{
			p.setY(mi.getPosition().getY()-1);
		}
		else if (dir.equals("right"))
		{
			p.setY(mi.getPosition().getY()+1);
		}
		
		return p;
	}
	
	@Override
	public void move(String dir){

		l.setSteps(l.getSteps()+1);
		
		ListIterator<Character> iterChars = l.getChars().listIterator();
		Character currentChar = iterChars.next(); //the only character for now
		
		ListIterator<Box> iterBoxes = l.getBoxes().listIterator(); 
		boolean found = false; //is there a box to the direction from the character
		while (iterBoxes.hasNext() && !found)
		{
			Box temp = iterBoxes.next();
			if (moveTo(currentChar, dir).equals(temp.getPosition()))
					{
						int add = 0;
						found = true;
						MySokobanPolicy msp = new MySokobanPolicy(l);
						if(msp.canMove(temp, moveTo(temp, dir))) //check policy on the box
						{
							if (signBoard[temp.getPosition().getX()][temp.getPosition().getY()]=='%') //box on star
							{
						
								if (signBoard[msp.getP().getX()][msp.getP().getY()]=='o') //box to star
								{}
								else
									add+=1;
								}
							else
							{
								if (signBoard[msp.getP().getX()][msp.getP().getY()]=='o') //box to star
									add-=1;
							}
							
							temp.move(dir);
							l.setNumOfStars(l.getNumOfStars()+add);
							currentChar.move(dir);
						}
					}
		}
		if (!found)
		{
			if (new MySokobanPolicy(l).canMove(currentChar,moveTo(currentChar, dir))) //check policy on character
			{
				currentChar.move(dir);
			}
		}
		
		signBoard = new SignBoard(l).getSignBoard();
	
		if (l.getNumOfStars()==0)
		{
			l.getTimer().stop();
			l.getTimer().getTime();
			l.getTimer().printTime();	
			System.out.println("YOU WON! Congratulations");
		}
	}
	
	@Override
	public void load(String fileName) {
		LoaderFactory lf = new LoaderFactory();
		LevelLoader ll = lf.createLoader(fileName);
		
		Level temp = new Level(ll.loadLevel(l.getIs())); //we set every member of level
		l.setBoard(temp.getBoard());
		l.setBoundCol(temp.getBoundCol());
		l.setBoundRow(temp.getBoundRow());
		l.setBoxes(temp.getBoxes());
		l.setChars(temp.getChars());
		l.setNumOfStars(temp.getNumOfStars());
		l.setSteps(temp.getSteps());
		l.setTimer(temp.getTimer());
		l.getTimer().start();
	}

	@Override
	public void save(String fileName) {
		SaverFactory lf = new SaverFactory();
		LevelSaver ll = lf.createSaver(fileName);
		ll.saveLevel(fileName,l);
	}

	@Override
	public void exit(Level l) {
		
		if (l.getIs() != null)
		{
			try {
				l.getIs().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		if (l.getOs() != null)
		{
			try {
				l.getOs().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public Level getLevel() {
		return l;
	}

	public Level getL() {
		return l;
	}

	public void setL(Level l) {
		this.l = l;
	}

	public char[][] getSignBoard() {
		return signBoard;
	}

	public void setSignBoard(char[][] signBoard) {
		this.signBoard = signBoard;
	}

}
