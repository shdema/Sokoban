/**
 * 
 */
package view;

/**
 * @author ����
 * Interface for any other window (not main)
 */
public interface WindowView {
	public void switchScene();
}
