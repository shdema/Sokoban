package view;

import commons.Level;
/**
 * Facade for the view layer.
 * @author Eon
 *
 */
public interface View {
	public void display(Level l);
}
