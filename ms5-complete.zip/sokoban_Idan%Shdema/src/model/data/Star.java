package model.data;

/**
 * A target for boxes.
 * @author ����
 *
 */
public class Star extends Item{

	Star(int x, int y) {
		super(x, y, "Star");
	}

}
