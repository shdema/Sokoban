package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;

import controller.commands.Command;
import controller.commands.CommandFactory;
import controller.server.Handler;
import controller.server.SokobanServer;
import model.Model;
import view.View;

public class SokobanController implements Observer {
	private Model model; // reference facade to model
	private View view; // reference facade to view
	private Controller controller; //reference to general Controller class 
	private SokobanServer server;
	
	private boolean serverOn = false; //a flag to see if we run on server or locally
	
	public SokobanController(Model model,View view){
			this.model = model;
			this.view = view;
			controller = new Controller();
			controller.start();
	}

	public void update(Observable obs, Object arg) {
		LinkedList<String> params = (LinkedList<String>) arg; //O(1) solution
		if (obs == model) {
			
			if (params.get(0).equals("notLoaded"))
			{
				if (serverOn)
					server.getCh().feedback(params.get(0));
				else
					view.displayMessage(params.get(0));
			}
			
			else //a level is currently loaded
			{
				
				if (serverOn)
				{
					if (params.get(0).equals("Load"))
						server.getCh().display(model.getLevel());
					else if (params.get(0).equals("Move"))
						server.getCh().display(model.getLevel());
					else if (params.get(0).equals("Display"))
						server.getCh().display(model.getLevel());
					else
						server.getCh().feedback(params.get(0));
				}
				
				else //GUI
				{
					//maybe switch case
					
					if (params.get(0).equals("Load"))
					{
						LinkedList<String> display = new LinkedList<String>();
						display.add("Display");
						CommandFactory cf = new CommandFactory(display,model,view,controller);
						Command c = cf.createCommand();
						controller.insertCommand(c);	
					}
					else if (params.get(0).equals("Move"))
					{
						LinkedList<String> display = new LinkedList<String>();
						display.add("Display");
						CommandFactory cf = new CommandFactory(display,model,view,controller);
						Command c = cf.createCommand();
						controller.insertCommand(c);	
					}
					else if (params.get(0).equals("Display"))
					{
						LinkedList<String> display = new LinkedList<String>();
						display.add("Display");
						CommandFactory cf = new CommandFactory(display,model,view,controller);
						Command c = cf.createCommand();
						controller.insertCommand(c);	
					}
					
					if (params.get(0).equals("Saved"))
					{
						view.displayMessage(params.get(0));
					}

						
				}
			}
			
		}
		
		if (obs == view) {// if view updates the controller
			
			if (!serverOn) //GUI
			{
				CommandFactory cf = new CommandFactory(params,model,view,controller);
				Command c = cf.createCommand();
				if (c != null) //c exists
				{
						controller.insertCommand(c);
						//l.getTimer().start(); - we added it to loadfilename execute
				}
				else
					view.displayMessage("noCommand");
			}
			else //SERVER
			{
				CommandFactory cf = new CommandFactory(params,model,view,controller);
				Command c = cf.createCommand();
				if (c != null) //c exists
				{
					if (cf.getParams().get(0).equals("Load")) //only allowed command
					{
						controller.insertCommand(c);
						//l.getTimer().start(); - we added it to loadfilename execute
					}
	
					else //not "Load"
					{
						if (cf.getParams().get(0).equals("Display")) //if the command is display
						{	
							server.getCh().display(model.getLevel());
						}
						
						else
						{
							controller.insertCommand(c);//there is a level, all commands allowed
						}
					}
				}
				else
				{
					server.getCh().feedback("noCommand");
				}
			}
		}
	}
	public HashMap<String, String> mapKeyCodes(File f)
	{

		Scanner s;
		
		try {
			HashMap<String, String> keyMap = new HashMap<String, String>();
			
			s = new Scanner(f);
			
			while (s.hasNextLine())
			{
				String str = s.nextLine();
				String[] keyVal = str.split(":");
				keyMap.put(keyVal[0], keyVal[1]);
			}
			s.close();
			return keyMap; 

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;

	}
	
	public void startServer(int port) throws Exception
	{
			server = new SokobanServer(port);
			server.start();
	}
	
	public void stopServer()
	{
			server.stop();
	}
	
	//gets and sets
	public Model getModel() {
		return model;
	}
	public void setModel(Model model) {
		this.model = model;
	}
	public View getView() {
		return view;
	}
	public void setView(View view) {
		this.view = view;
	}
	public Controller getController() {
		return controller;
	}
	public void setController(Controller controller) {
		this.controller = controller;
	}
	public void setServerOn() {
		serverOn = true;		
	}
	public SokobanServer getServer() {
		return server;
	}
}

