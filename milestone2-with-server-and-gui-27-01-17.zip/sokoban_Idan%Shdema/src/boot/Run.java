package boot;


import commons.Level;
import controller.SokobanController;
import controller.server.SokobanServer;
import model.MyModel;
import view.GUI;
import view.View;

public class Run {

	public static void main(String[] args) {

		
		MyModel model = new MyModel(new Level());
		SokobanController c = new SokobanController(model,null);
		model.addObserver(c);
		if (args[0].equals("-server"))
			try {
				c.startServer(Integer.parseInt(args[1]));
				c.setView((View) c.getServer().getCh());
				c.getServer().getCh().addObserver(c);
				c.setServerOn();
			} catch (Exception e) {
				// parsing exception
				e.printStackTrace();
			}
		


		

		
	}
}
