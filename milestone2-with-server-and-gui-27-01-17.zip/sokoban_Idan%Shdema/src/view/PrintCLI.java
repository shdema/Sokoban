package view;

import java.io.OutputStream;
import java.io.PrintWriter;

import commons.Level;
import commons.SignBoard;

/**
 * Prints to screen the game, steps counter and stars left.
 * @author ����
 *
 */
public class PrintCLI implements Printer {

	@Override
	public void print(Level l, PrintWriter pw) {
		char[][] signBoard = new SignBoard(l).getSignBoard();
		for (int i = 0; i < l.getBoundCol(); i++) 
		{
			pw.println(signBoard[i]);
			pw.flush();
		}
		pw.println("Steps: "+l.getSteps());
		pw.flush();
		pw.println("Stars left: "+l.getNumOfStars());
		pw.flush();
//		l.getTimer().stop();
//		l.getTimer().setTime(l.getTimer().getTime());
//		l.getTimer().printTime();
//		l.getTimer().start();
	}
}

