package view;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Observable;
import java.util.ResourceBundle;

import commons.Level;
import commons.SignBoard;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class MainWindowController extends Observable implements Initializable, View {
	private Stage primaryStage;
	private char[][] sokobanData;
	private HashMap<String,String> keyMap;
	
	@FXML
	SokobanDisplayer sokobanDisplayer;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) { //is called when the class is made, and we can also call it again in other places
		sokobanDisplayer.setSokobanData(sokobanData); //controller sends signboard
		
		sokobanDisplayer.addEventFilter(MouseEvent.MOUSE_CLICKED, (e)->sokobanDisplayer.requestFocus()); //when we click on the displayer with the mouse the focus will go to the displayer 
		sokobanDisplayer.setFocusTraversable(true);
		sokobanDisplayer.setOnKeyPressed(new EventHandler<KeyEvent>() {

			@Override
			public void handle(KeyEvent event) {
				String direction = "";
				if (event.getCode().getName().equals(keyMap.get("up"))){
					direction = "up";
				}
				else if (event.getCode().getName().equals(keyMap.get("down"))){
					direction = "down";
				}
				else if (event.getCode().getName().equals(keyMap.get("right"))){
					direction = "right";
				}
				else if (event.getCode().getName().equals(keyMap.get("left"))){
					direction = "left";
				}
				
				LinkedList<String> params = new LinkedList<String>();
				params.add("Move");
				params.add(direction);
				
				setChanged();
				notifyObservers(params);				
			}
		});
	}	
	
    //create reference to main window
	public void start() {
		System.out.println("start");
	}
	
	public void openFile(){
		FileChooser fc = new FileChooser();
		fc.setTitle("Open Sokoban file"); //title for the file dialog
		fc.setInitialDirectory(new File("./")); //the directory to open
		fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("XML Files","*.xml")); //file types to choose from
		File chosen = fc.showOpenDialog(primaryStage); //return main window 
		if (chosen!=null)
			System.out.println(chosen.getName());
		
		
		
		LinkedList<String> params = new LinkedList<String>();
		params.add("Load");
		params.add(chosen.getName());
		
		setChanged();
		notifyObservers(params);

		//if loaded correctly - display
		
		LinkedList<String> params2 = new LinkedList<String>();
		params2.add("Display");
		
		setChanged();
		notifyObservers(params2);
	}
	
	public void saveFile(){

			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Save current level as"); //title for the file dialog
			fileChooser.setInitialDirectory(new File("./")); //the directory to open
	        //Set extension filter
	        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("XML file", "*.xml");
	        fileChooser.getExtensionFilters().add(extFilter);
	        
	        //Show save file dialog
	        File file = fileChooser.showSaveDialog(primaryStage);
			LinkedList<String> params = new LinkedList<String>();
			params.add("Save");
			params.add(file.getName());
			
			setChanged();
			notifyObservers(params);

//			Alert alert = new Alert(AlertType.WARNING);
//			alert.setTitle("WARNING!!!");
//			alert.setHeaderText("Load a level first!");
//			alert.setContentText("Cannot save.");
//	
//			alert.showAndWait();

	}
	
	public void exitGame(){
		LinkedList<String> params = new LinkedList<String>();
		params.add("Exit");
		
		setChanged();
		notifyObservers(params);
        exitApplication();
	}
	
	public void setStage(Stage primaryStage)
	{
		this.primaryStage = primaryStage;
	}

	@Override
	public void displayMessage(String msg) {
		if (msg.equals("notLoaded"))
		{
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("WARNING!!!");
			alert.setHeaderText("Load a level first!");
			alert.setContentText("Please load a level.");
	
			alert.showAndWait();
		}
		
		else if (msg.equals("Saved"))
		{
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Level saved");
			alert.setHeaderText("Level saved successfully!");
	
			alert.showAndWait();
		}
		
		else if (msg.equals("noCommand"))
		{
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("WARNING!!!");
			alert.setHeaderText("Command not recognized.");
	
			alert.showAndWait();
		}
	}

	@Override
	public void display(Level l) {

		sokobanData = new SignBoard(l).getSignBoard(); //init sokobanData with signboard from l
		sokobanDisplayer.setSokobanData(sokobanData);
		sokobanDisplayer.redraw();
	
	}

	@Override
	public void exit(Level l) {
		// TODO Auto-generated method stub
	}
	
	@FXML
	public void exitApplication() {
	   Platform.exit();
	}

	public HashMap<String, String> getKeyMap() {
		return keyMap;
	}

	public void setKeyMap(HashMap<String, String> keyMap) {
		this.keyMap = keyMap;
	}

}
