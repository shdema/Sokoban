package view;

import java.net.URL;
import java.util.LinkedList;
import java.util.Observable;
import java.util.ResourceBundle;

import commons.Level;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import model.db.Score;

public class DetailsWindowController extends Observable implements Initializable, View{

	@FXML
	TextField fName;
	
	@FXML
	TextField lName;
	
	@FXML
	TextField Iduser;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub		
	}
	public void setDetails(){
		LinkedList<String> params = new LinkedList<String>();
		params.add("Details"); // so the controller knows it's the user details 
		params.add(fName.getText());
		params.add(lName.getText());
		params.add(Iduser.getText()); // casting to int when receive
		setChanged();
		notifyObservers(params);
	}
	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void displayMessage(String msg) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void display(Level l) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void exit(Level l) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void bindTime(StringProperty time) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void bindSteps(IntegerProperty steps) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setScoreList(LinkedList<Score> arg) {
		// TODO Auto-generated method stub
		
	}
	

}
