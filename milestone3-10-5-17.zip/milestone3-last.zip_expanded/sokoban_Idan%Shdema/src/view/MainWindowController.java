package view;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Optional;
import java.util.ResourceBundle;

import commons.Level;
import commons.SignBoard;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.db.Score;

/**
 * The GUI controller, it's a view implementation, observed by
 * SokobanController.<br>
 * Contains methods for the menu: loading, saving and exiting.<br>
 * Exits in the right order and closes everything that's open in the GUI.
 * 
 * @author Eon
 *
 */
public class MainWindowController extends Observable implements Initializable, View {
	private Stage primaryStage;
	private FXMLLoader loader;

	private char[][] sokobanData;
	private HashMap<String, String> keyMap;
	private boolean loaded;
	private MediaPlayer mp;
	LinkedList<Score> scoreList;
	ObservableList<Score> obsList;
//	private Scene otherScene;

	@FXML
	SokobanDisplayer sokobanDisplayer;

	@FXML
	Label clock;

	@FXML
	Label steps;

	@FXML
	TextField fName;
	
	@FXML
	TextField lName;
	
	@FXML
	TextField Iduser;
	
	// is called when the class is made, and we can also call it again in other
	// places
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		String path = "./resources/music.mp3";
		Media media = new Media(new File(path).toURI().toString());
		mp = new MediaPlayer(media);

		loaded = false;
		
		sokobanDisplayer.setSokobanData(sokobanData); // controller sends
														// signboard

		sokobanDisplayer.setFocusTraversable(true);
		sokobanDisplayer.setOnKeyPressed(new EventHandler<KeyEvent>() {

			@Override
			public void handle(KeyEvent event) {
				String direction = "";
				if (event.getCode().getName().equals(keyMap.get("up"))) {
					try {
						loader.setRoot(null);
						loader.setController(null);
						Pane details = loader.load(getClass().getResource("DetailsWindow.fxml").openStream());

						Scene scene = new Scene(details, 600, 600);
//						Scene detailsScene = new Scene(details, 800, 800);
						scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
						primaryStage.setScene(scene);
//						view.setScene(detailsScene);
						primaryStage.show();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					direction = "up";
				} else if (event.getCode().getName().equals(keyMap.get("down"))) {
					direction = "down";
				} else if (event.getCode().getName().equals(keyMap.get("right"))) {
					sokobanDisplayer.setCharFileName(sokobanDisplayer.getBobRightFileName());
					direction = "right";
				} else if (event.getCode().getName().equals(keyMap.get("left"))) {
					sokobanDisplayer.setCharFileName(sokobanDisplayer.getBobLeftFileName());
					direction = "left";
				}

				if (!direction.equals("")) {
					LinkedList<String> params = new LinkedList<String>();
					params.add("Move");
					params.add(direction);

					setChanged();
					notifyObservers(params);
				}
			}
		});
	}

	public void openFile() {
		FileChooser fc = new FileChooser();
		fc.setTitle("Open Sokoban file"); // title for the file dialog
		fc.setInitialDirectory(new File("./")); // the directory to open
		fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("XML Files", "*.xml")); // file
																								// types
																								// to
																								// choose
																								// from
		File chosen = fc.showOpenDialog(primaryStage); // return main window

		LinkedList<String> params = new LinkedList<String>();
		params.add("Load");
		params.add(chosen.getName());

		setChanged();
		notifyObservers(params);

		// load music
		if (mp != null)
			mp.stop();

		mp.setAutoPlay(true);
		mp.play();

		// if loaded correctly - display
		LinkedList<String> params2 = new LinkedList<String>();
		params2.add("Display");

		setChanged();
		notifyObservers(params2);

		loaded = true;
	}

	public void saveFile() {

		if (!loaded) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("WARNING!!!");
			alert.setHeaderText("Load a level first!");
			alert.setContentText("Cannot save.");

			alert.showAndWait();
		} else {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Save current level as"); // title for the file
															// dialog
			fileChooser.setInitialDirectory(new File("./")); // the directory to
																// open
			// Set extension filter
			FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("XML file", "*.xml");
			fileChooser.getExtensionFilters().add(extFilter);

			// Show save file dialog
			File file = fileChooser.showSaveDialog(primaryStage);
			LinkedList<String> params = new LinkedList<String>();
			if (file!=null)
			{
				params.add("Save");
				params.add(file.getName());
				setChanged();
				notifyObservers(params);
			}
		}

	}

	public void exitGame() {
		LinkedList<String> params = new LinkedList<String>();
		params.add("Exit");

		setChanged();
		notifyObservers(params);
		if (loaded) {
			mp.dispose();
		}
		exitApplication();
	}

	public void setStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	@Override
	public void displayMessage(String msg) {
		if (msg.equals("notLoaded")) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("WARNING!!!");
			alert.setHeaderText("Load a level first!");
			alert.setContentText("Please load a level.");

			alert.showAndWait();
		}

		else if (msg.equals("Saved")) {
			Platform.runLater(new Runnable() { // move to JavaFX thread

				@Override
				public void run() {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Level saved");
					alert.setHeaderText("Level saved successfully!");

					alert.showAndWait();
				}
			});
		}

		else if (msg.equals("noCommand")) {
			Platform.runLater(new Runnable() { // move to JavaFX thread

			@Override
			public void run() {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("WARNING!!!");
				alert.setHeaderText("Command not recognized.");
	
				alert.showAndWait();
				}
			});
		}
		else if (msg.equals("WIN")) {


			Platform.runLater(new Runnable() { // move to JavaFX thread

				@Override
				public void run() {
					Dialog<ButtonType> dialog = new Dialog<>();
					dialog.setTitle("Your details");
					dialog.setHeaderText("You won! Please enter your details:");

					dialog.setOnCloseRequest(new EventHandler<DialogEvent>() {
					    @Override public void handle(DialogEvent e) {
							dialog.close();
					    }
					});

					ButtonType insert = new ButtonType("Insert");					
					ButtonType cancel = new ButtonType("Cancel");
					dialog.getDialogPane().getButtonTypes().setAll(insert,cancel);
					
					
					GridPane grid = new GridPane();
					grid.setHgap(10);
					grid.setVgap(10);
					grid.setPadding(new Insets(20, 150, 40, 10));

					TextField firstname = new TextField();
					firstname.setPromptText("First name:");
					TextField lastname = new TextField();
					lastname.setPromptText("Last name:");
					TextField id = new TextField();
					id.setPromptText("*ID Number:");

					grid.add(new Label("First name:"), 0, 0);
					grid.add(firstname, 1, 0);
					grid.add(new Label("Last name:"), 0, 1);
					grid.add(lastname, 1, 1);
					grid.add(new Label("*ID Number:"), 0, 2);
					grid.add(id, 1, 2);

					// Enable/Disable login button depending on whether a username was entered.
//					Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
//					loginButton.setDisable(true);



					dialog.getDialogPane().setContent(grid);

					// Request focus on the username field by default.
					Platform.runLater(() -> firstname.requestFocus());

					Optional<ButtonType> result = dialog.showAndWait();		

					
					// Do some validation (using the Java 8 lambda syntax).
//					id.textProperty().addListener((observable, oldValue, newValue) -> {
//					    insert.setDisable(newValue.trim().isEmpty());
//					});
					
					if (result.get() == cancel)
					{
						dialog.close();
					}
					else if (result.get() == insert)
					{
							LinkedList<String> params = new LinkedList<String>();
							params.add("Details"); // so the controller knows it's the user details 
							params.add(firstname.textProperty().getValue());
							params.add(lastname.textProperty().getValue());
							params.add(id.textProperty().getValue()); // casting to int when receive
							setChanged();
							notifyObservers(params);
							dialog.close();
							openScoreboard();
					}
					


//					result.ifPresent(usernamePassword -> {
//					    System.out.println("Username=" + usernamePassword.getKey() + ", Password=" + usernamePassword.getValue());
//					});
					
					
//					primaryStage.setScene(otherScene);
					
//					Alert alert = new Alert(AlertType.INFORMATION);
//					alert.setTitle("YOU WON");
//					alert.setHeaderText("Good game!");
//
//					alert.showAndWait();
//
//					// enter details window
				}
			});
		}
	}

	private void openScoreboard(){
		obsList = FXCollections.observableArrayList();
		TableView table = new TableView<>();
		TableColumn<Score, Integer> userID = new TableColumn<>("UserID");
		TableColumn<Score, String> levelID = new TableColumn<>("Level name");
		TableColumn<Score, Integer> steps = new TableColumn<>("Steps");
		TableColumn<Score, Integer> time = new TableColumn<>("Time");

		userID.setCellValueFactory(new PropertyValueFactory<Score, Integer>("UserID"));
		levelID.setCellValueFactory(new PropertyValueFactory<Score, String>("LevelID"));
		steps.setCellValueFactory(new PropertyValueFactory<Score, Integer>("Steps"));
		time.setCellValueFactory(new PropertyValueFactory<Score, Integer>("Time"));
		
	    userID.setSortable(false);
		
		LinkedList<String> params = new LinkedList<String>();
		params.add("topScores");
		setChanged();
		notifyObservers(params);
		
		table.setItems(obsList);
		table.getColumns().addAll(userID,levelID,steps,time);
		
		
		
		table.setEditable(false);
		table.getSelectionModel().setCellSelectionEnabled(true);  // selects cell only, not the whole row
		table.setOnMouseClicked(new EventHandler<MouseEvent>() {
		 @Override
		 public void handle(MouseEvent click) {
		  if (click.getClickCount() == 2) {
		   @SuppressWarnings("rawtypes")
		   TablePosition pos = (TablePosition) table.getSelectionModel().getSelectedCells().get(0);
		   int row = pos.getRow();
		   int col = pos.getColumn();
		   @SuppressWarnings("rawtypes")
		   TableColumn column = pos.getTableColumn();
		   String val = column.getCellData(row).toString(); 
		   System.out.println("Selected Value, " + val + ", Column: " + col + ", Row: " + row);
		   if ( col == 0 ) {
			   obsList.removeAll(obsList);
			   LinkedList<String> params = new LinkedList<String>();
			   params.add("topScoresUser");
			   params.add(val);
			   setChanged();
			   notifyObservers(params);
			   table.setItems(obsList);
		   } 
		   else if ( col == 1 ) {
			   obsList.removeAll(obsList);
			   params.add("topScoresLevel");
			   params.add(val);
			   setChanged();
			   notifyObservers(params);
			   table.setItems(obsList);
		   } 
		  }
		 }
		});
		
		
//		Popup popup = new Popup();
//	    popup.setX(800);
//	    popup.setY(800);
		
		//dialog window scoreboard
		
		Dialog<ButtonType> dialog = new Dialog<>();
		dialog.setTitle("SCOREBOARD");
//		dialog.setHeaderText("You won! Please enter your details:");

//		dialog.setOnCloseRequest(new EventHandler<DialogEvent>() {
//		    @Override public void handle(DialogEvent e) {
//				dialog.close();
//		    }
//		});
		
		
		TextField filter = new TextField();
		filter.setPromptText("Filter by user/level:");
		
//		onKey
//		filter.textProperty().addListener((observable, oldValue, newValue) -> {
//		    System.out.println("textfield changed from " + oldValue + " to " + newValue);
//		   obsList.removeAll(obsList);
//		   LinkedList<String> params3 = new LinkedList<String>();
//		   params3.add("topScoresUser");
//		   params3.add(newValue);
//		   setChanged();
//		   notifyObservers(params);
//		   table.setItems(obsList);
//		});
		
		
		
		ButtonType back = new ButtonType("Back");					
		ButtonType exit = new ButtonType("Exit to game", ButtonData.CANCEL_CLOSE);
		dialog.getDialogPane().getButtonTypes().setAll(back,exit);
		
		Node button = dialog.getDialogPane().lookupButton(back);
		
		button.setOnMouseClicked(new EventHandler<MouseEvent>() {
		    @Override public void handle(MouseEvent e) {
				   obsList.removeAll(obsList);
				   LinkedList<String> params2 = new LinkedList<String>();
				   params2.add("topScores");
				   setChanged();
				   notifyObservers(params2);
				   table.setItems(obsList);
				;}
		});
		
		GridPane grid = new GridPane();
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(20, 20, 20, 20));
		grid.add(filter, 0, 0);
		grid.add(table, 0, 1);


		dialog.getDialogPane().setContent(grid);
		
//		Platform.runLater(() -> firstname.requestFocus());

//		dialog.setOnAction(new EventHandler() {
//			public void handle(ActionEvent actionEvent) {
//			if (actionEvent.getEventType() instanceof CancelEvent) {
//			// �
//			}
//			}
//
//			@Override
//			public void handle(Event arg0) {
//				// TODO Auto-generated method stub
//				
//			}
//			});
		
		dialog.show();
		
		
//		if (result.get() == back)
//		{
//		   obsList.removeAll(obsList);
//		   LinkedList<String> params2 = new LinkedList<String>();
//		   params2.add("topScores");
//		   setChanged();
//		   notifyObservers(params2);
//		   table.setItems(obsList);
//		}
//		else if (result.get() == exit)
//		{
//			dialog.close();
//		}
//	    popup.getContent().addAll(table);
//	    ButtonType quit = new ButtonType("Quit");
//	    Button quit = new Button("Quit");
//	    quit.setOnAction(new EventHandler<ActionEvent>() {
//	    	@Override public void handle(ActionEvent e) {
//					popup.hide();
//					}
//		});
//	    popup.centerOnScreen();

	    
//	    popup.show(primaryStage);
//	    primaryStage.show();

	}
	
	@Override
	public void display(Level l) {
		sokobanData = new SignBoard(l).getSignBoard(); // init sokobanData with
														// signboard from l
		sokobanDisplayer.setSokobanData(sokobanData);
		sokobanDisplayer.redraw();
	}

	@Override
	public void exit(Level l) {
		Platform.exit();
	}

	@FXML
	public void exitApplication() {
		System.exit(0);
	}

	public HashMap<String, String> getKeyMap() {
		return keyMap;
	}

	public void setKeyMap(HashMap<String, String> keyMap) {
		this.keyMap = keyMap;
	}

	@Override
	public void bindTime(StringProperty time) {
		this.clock.textProperty().bind(time);
	}

	@Override
	public void bindSteps(IntegerProperty steps) {
		this.steps.textProperty().bind(steps.asString());
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub

	}

//	public void setScene(Scene detailsScene) {
//		otherScene = detailsScene;
//	}
	public void setDetails(){
		LinkedList<String> params = new LinkedList<String>();
		params.add("Details"); // so the controller knows it's the user details 
		params.add(fName.getText());
		params.add(lName.getText());
		params.add(Iduser.getText()); // casting to int when receive
		setChanged();
		notifyObservers(params);
	}

	@Override
	public void setScoreList(LinkedList<Score> arg) {
		scoreList = arg;
		if (scoreList!=null)
		{
			for (int i = 0; i < scoreList.size(); i++) {
				obsList.add(scoreList.get(i));
			}
		}
	}

	public FXMLLoader getLoader() {
		return loader;
	}

	public void setLoader(FXMLLoader loader) {
		this.loader = loader;
	}

//	@Override
//	public void update(Observable arg0, Object arg1) {
//		if (obs=="DetailsWindowController")
//	}
}
