package controller;

import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;

import controller.commands.Command;
import controller.commands.CommandFactory;
import model.Model;
import model.data.Level;
import view.View;

public class SokobanController implements Observer {
	private Model model; // reference facade to model
	private View view; // reference facade to view
	private Controller controller; //reference to general Controller class 
	private Level l;
	
	public SokobanController(Model model,View view){
			this.model = model;
			this.view = view;
			
			controller = new Controller();
			controller.start();
	}
//Map  - to do and to change update accordingly
	public void update(Observable obs, Object arg) {
		LinkedList<String> params = (LinkedList<String>) arg; 
		if (obs == model) { // if model updates the controller
			// m methods
		}
		
		if (obs == view) { // if view updates the controller
			CommandFactory cf = new CommandFactory(params,model.getLevel(),model,view,controller);
			Command c = cf.createCommand();
			if (c != null) //c exists
			{
				if (cf.getParams().get(0).equals("Load")) //only allowed command
				{
					//model should execute and start the timer
					//c.execute();
					controller.insertCommand(c);
					//l.getTimer().start(); - we added it to loadfilename execute
				}

				else //not "Load"
				{
					controller.insertCommand(c); //there is a level, all commands allowed

				}
			}
			else
				view.displayMessage("No such command.\n");
		}
	}
}

