package controller.server;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import view.CLI;

public class Handler implements ClientHandler {
	
	private List<String> params;
	
	
	@Override
	public void handleClient(InputStream inFromClient, OutputStream outToClient) {
//		CLI cli = new CLI();
//		cli.start();
		//set params
	}

}
