package controller.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Observable;


public class SokobanServer extends Observable {
	
	private int port;
	private ClientHandler ch;
	
	public SokobanServer(int port, ClientHandler ch) {
		this.port = port;
		this.ch = ch;
	}
	
	private void runServer() throws Exception{
		ServerSocket server = new ServerSocket(port);
		server.setSoTimeout(1000);
		try {
			Socket aClient = server.accept(); //blocking call - waits for client to connect
			new Thread(new Runnable() {
				public void run() {
					try {
						ch.handleClient(aClient.getInputStream(), aClient.getOutputStream());
						setChanged();
						notifyObservers(ch.params);
						aClient.getInputStream().close();
						aClient.getOutputStream().close();
						aClient.close();
					} catch (IOException e) {/*...*/}
				}
			}).start();
			
		} catch (SocketTimeoutException e) { /* say something */ }
		
		server.close();
	}
	
	
}
