package view;

import model.data.Level;

/**
 * Printing Interface
 * @author ����
 *
 */
public interface Printer {
	public void print(Level l);
}
