package view;

import commons.SignBoard;
import model.data.Level;

/**
 * Prints to screen the game, steps counter and stars left.
 * @author ����
 *
 */
public class PrintCLI implements Printer {

	@Override
	public void print(Level l) {
		char[][] signBoard = new SignBoard(l).getSignBoard();
		for (int i = 0; i < l.getBoundCol(); i++) 
		{
			System.out.println(signBoard[i]);
		}
		System.out.println("Steps: "+l.getSteps());
		System.out.println("Stars left: "+l.getNumOfStars());	
	}
}

