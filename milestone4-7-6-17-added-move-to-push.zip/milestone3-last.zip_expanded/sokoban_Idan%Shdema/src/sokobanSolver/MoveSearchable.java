package sokobanSolver;

import java.util.HashMap;

import model.data.Position;
import searchLib.SearchLibAction;
import searchLib.State;
import searchLib.TwoPositions;

public class MoveSearchable extends CommonSokobanSearchable<Position> {

	public MoveSearchable(char[][] sb, Position init, Position goal) {
		super(sb);
		initState = new State<Position>(new Position(init.getX(), init.getY()));
		goalState = new State<Position>(new Position(goal.getX(), goal.getY()));
	}
	
	@Override
	public HashMap<SearchLibAction, State<Position>> getAllPossibleMoves(State<Position> state) {
		
		int x = state.getState().getX();
		int y = state.getState().getY();
		
		Position r = new Position(x,y+1);
		Position l = new Position(x,y-1);		
		Position u = new Position(x-1,y);
		Position d = new Position(x+1,y);
		
		State<Position> sr = new State<Position>(r);
		State<Position> sl = new State<Position>(l);
		State<Position> su = new State<Position>(u);
		State<Position> sd = new State<Position>(d);
		
		sr.setAction(new SearchLibAction("Move right"));
		sl.setAction(new SearchLibAction("Move left"));
		su.setAction(new SearchLibAction("Move up"));
		sd.setAction(new SearchLibAction("Move down"));
		
		if(inSignBoard(r) && isClear(r))
			map.put(new SearchLibAction("Move right"), sr);
		if(inSignBoard(l) && isClear(l))
			map.put(new SearchLibAction("Move left"), sl);
		if(inSignBoard(u) && isClear(u))
			map.put(new SearchLibAction("Move up"), su);
		if(inSignBoard(d) && isClear(d))
			map.put(new SearchLibAction("Move down"), sd);
		return map;
	}
	
	boolean isClear(Position p) {
		if (signB[p.getX()][p.getY()]!='#' && signB[p.getX()][p.getY()]!='@')
		{
				return true;
		}
		return false;
	}
}
