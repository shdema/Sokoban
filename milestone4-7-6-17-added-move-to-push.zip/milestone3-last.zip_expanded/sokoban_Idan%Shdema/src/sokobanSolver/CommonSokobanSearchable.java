package sokobanSolver;

import model.data.Position;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import searchLib.SearchLibAction;
import searchLib.Searchable;
import searchLib.State;

public abstract class CommonSokobanSearchable<T> implements Searchable<T> {
	char[][] signB;
	State<T> initState;
	State<T> goalState;
	HashMap<SearchLibAction, State<T>> map;
//	ArrayList<State<Position>> list;
	
	public CommonSokobanSearchable(char[][] sb){
		signB=sb;
		initState = null;
		goalState = null;
		map = new HashMap<>();
//		list = new ArrayList<>();
	}
	
	
	public boolean inSignBoard(Position p)
	{
		int x = p.getX();
		int y = p.getY();
		if (x<signB.length && x>=0 && y<signB[0].length && y>=0)
			return true;
		return false;
	}
	
	@Override
	public State<T> getInitialState() {
		return initState;
	}
	
	@Override
	public State<T> getGoalState() {
		return goalState;
	}
	
	@Override
	public abstract HashMap<SearchLibAction, State<T>> getAllPossibleMoves(State<T> state);
//	public abstract ArrayList<State<Position>> getAllPossibleMoves(State<Position> state);


}
