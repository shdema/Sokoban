package sokobanSolver;

import java.util.HashMap;

import model.data.Position;
import searchLib.BFS;
import searchLib.SearchLibAction;
import searchLib.Searchable;
import searchLib.Searcher;
import searchLib.Solution;
import searchLib.State;
import searchLib.TwoPositions;

public class PushSearchable extends CommonSokobanSearchable<TwoPositions> {

	State<TwoPositions> lastState;
	
	public PushSearchable(char[][] sb, int initX, int initY, int goalX, int goalY, int sokX, int sokY) {
		super(sb);
		initState = new State<TwoPositions>(new TwoPositions(new Position(initX, initY), new Position(sokX, sokY)));
		goalState = new State<TwoPositions>(new TwoPositions(new Position(goalX, goalY)));
	}
	

	//TODO: check that sokoban can reach the box
	@Override
	public HashMap<SearchLibAction, State<TwoPositions>> getAllPossibleMoves(State<TwoPositions> state) {
		
		if (state.getCameFrom() == null) //initial state (first push of this box)
		{
			lastState = initState;
		}
		else
			lastState = state.getCameFrom();
		
		int x = state.getState().getBox().getX();
		int y = state.getState().getBox().getY();
		
		Position r = new Position(x,y+1);
		Position l = new Position(x,y-1);		
		Position u = new Position(x-1,y);
		Position d = new Position(x+1,y);
		
		Position boxP = state.getState().getBox();
		
		//set the new states to move to (sokoban will take the current place of box)
		State<TwoPositions> sr = new State<TwoPositions>(new TwoPositions(r,boxP));
		State<TwoPositions> sl = new State<TwoPositions>(new TwoPositions(l,boxP));
		State<TwoPositions> su = new State<TwoPositions>(new TwoPositions(u,boxP));
		State<TwoPositions> sd = new State<TwoPositions>(new TwoPositions(d,boxP));
		
		//each state holds the action that led to its state
		sr.setAction(new SearchLibAction("Move right"));
		sl.setAction(new SearchLibAction("Move left"));
		su.setAction(new SearchLibAction("Move up"));
		sd.setAction(new SearchLibAction("Move down"));
		
		if (inSignBoard(r) && inSignBoard(l))
		{
			if(isClear(r,boxP)&&isClear(l,boxP))
			{
				Solution actionsLeft = moveSokoban(super.signB, state.getState().getSok(),l);
				if (actionsLeft != null)
					map.put(sr.getAction(), sr);
				Solution actionsRight = moveSokoban(super.signB,state.getState().getSok(),r);
				if (actionsRight != null)
					map.put(sl.getAction(), sl);
			}
		}
		if (inSignBoard(u) && inSignBoard(d))
		{
			if(isClear(u,boxP)&&isClear(d,boxP))
			{
				Solution actionsDown = moveSokoban(super.signB, state.getState().getSok(),d);
				if (actionsDown != null)
					map.put(su.getAction(), su);
				Solution actionsUp = moveSokoban(super.signB, state.getState().getSok(),u);
				if (actionsUp != null)
					map.put(sd.getAction(), sd);
			}
		}
		return map;
	}

	boolean isClear(Position p, Position boxP){
		if (signB[p.getX()][p.getY()]!='#')
		{
			if (signB[p.getX()][p.getY()]!='@')
				return true;
			if (signB[p.getX()][p.getY()]=='@' && p.equals(boxP))
				return true;
		}
		return false;
	}

	private Solution moveSokoban(char[][] sb, Position start, Position end) {
		Searcher<Position> searcher = new BFS<Position>();
		Searchable<Position> fromWhere = new MoveSearchable(sb, start, end);
		Solution actions = searcher.search(fromWhere);
		return actions;
	}

	public State<TwoPositions> getLastState() {
		return lastState;
	}


	public void setLastState(State<TwoPositions> lastState) {
		this.lastState = lastState;
	}


}
