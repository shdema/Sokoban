package searchLib;

import model.data.Position;

public class TwoPositions {
	Position box, sok;

	public Position getBox() {
		return box;
	}

	public void setBox(Position box) {
		this.box = box;
	}

	public Position getSok() {
		return sok;
	}

	public void setSok(Position sok) {
		this.sok = sok;
	}

	public TwoPositions(Position box, Position sok) {
		this.box = box;
		this.sok = sok;
	}
	
	public TwoPositions(Position box)
	{
		this.box = box;
	}
	
}
