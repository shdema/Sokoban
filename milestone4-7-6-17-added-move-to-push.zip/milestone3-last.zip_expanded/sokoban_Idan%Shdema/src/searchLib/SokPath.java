package searchLib;

import java.util.LinkedList;

public class SokPath extends SearchLibAction {

	LinkedList<SearchLibAction> actions;
	
	public SokPath(String name) {
		super(name);
		actions.add(new SearchLibAction(name));
		// TODO Auto-generated constructor stub
	}

	public LinkedList<SearchLibAction> getActions() {
		return actions;
	}

	public void setActions(LinkedList<SearchLibAction> actions) {
		this.actions = actions;
	}
	

}
