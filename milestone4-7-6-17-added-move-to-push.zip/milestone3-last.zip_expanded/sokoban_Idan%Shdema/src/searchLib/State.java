package searchLib;

public class State<T> {
	private T state;
	private State<T> cameFrom;
	private SearchLibAction action;
	private double cost;

	public State(T state) {
		this.state=state;
		cost=Double.MAX_VALUE; //infinity (very large)
	}
	public T getState() {	
		return state;
	}
	public void setState(T state) {
		this.state = state;
	}
	public State<T> getCameFrom() {
		return cameFrom;
	}
	public void setCameFrom(State<T> cameFrom) {
		this.cameFrom = cameFrom;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public SearchLibAction getAction() {
		return action;
	}
	public void setAction(SearchLibAction action) {
		this.action = action;
	}
	
	@Override
	public String toString() {
		return state.toString();
	}
	
	@Override
	public int hashCode() {
		return state.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		State<T> s = (State<T>)obj;
		return state.equals(s.state);
	}
	
}

