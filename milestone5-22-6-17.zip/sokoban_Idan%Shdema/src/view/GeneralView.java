/**
 * 
 */
package view;
/**
 * @author Eon
 *
 */
public interface GeneralView {
	public void switchScene();
}
