package view;

import java.util.LinkedList;

import model.db.Score;
/**
 * A view interface for the scoreboard window
 * @author ����
 *
 */
public interface DBView extends GeneralView {

	void setScoreList(LinkedList<Score> scoreList);

	void updateTable();

}
