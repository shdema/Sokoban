package model.data;

import java.io.IOException;
import java.io.OutputStream;

import commons.Level;

/**
 * XML saver - by serialization.
 * @author ����
 *
 */
public class MyXMLLevelSaver implements LevelSaver {

	@Override
	public void saveLevel(String fileName, Level l) {

			try {
				Serialization.writeSer(l, fileName); //write the level into obj file
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

}
