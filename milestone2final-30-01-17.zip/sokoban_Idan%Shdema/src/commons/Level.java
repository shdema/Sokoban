package commons;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.*;

import model.data.Box;
import model.data.Character;
import model.data.Item;
import model.data.MyTimer;

/**
 * Level class, has a board that is array list of array lists, array list of chars and array list of boxes.
 * @author ����
 *
 */
public class Level implements Serializable{
	
	//data members
	private ArrayList<ArrayList<Item>> board;
	private ArrayList<Character> chars;
	private ArrayList<Box> boxes;
	
	private int boundRow;//number of columns
	private int boundCol;//number of rows
	
	private MyTimer timer;
	private int steps;
	private int numOfStars;//counts the number of uncovered stars
	
	private transient InputStream is;
	private transient OutputStream os;
	
	//c'tors
	public Level()
	{
		board = new ArrayList<ArrayList<Item>>();
		chars = new ArrayList<Character>();
		boxes = new ArrayList<Box>();
		timer = new MyTimer();
		steps = 0;
		boundRow = 0;
		boundCol = 0;
		numOfStars = 0;
		is = null;
		os = null;
		
	}
	
	public Level(Level l) //copy c'tor
	{
		this.board = l.board;
		this.chars = l.chars;
		this.boxes = l.boxes;
		this.timer = l.timer;
		this.steps = l.steps;
		this.boundRow = l.boundRow;
		this.boundCol = l.boundCol;
		this.numOfStars = l.numOfStars;
		this.is = l.is;
		this.os = l.os;
	}
	

	//gets and sets
	public ArrayList<ArrayList<Item>> getBoard() {
		return board;
	}

	//not for use - just for serial
	public void setBoard(ArrayList<ArrayList<Item>> board) {
		this.board = board;
	}

	public ArrayList<Character> getChars() {
		return chars;
	}

	public void setChars(ArrayList<Character> chars) {
		this.chars = chars;
	}

	public ArrayList<Box> getBoxes() {
		return boxes;
	}

	public void setBoxes(ArrayList<Box> boxes) {
		this.boxes = boxes;
	}

	public MyTimer getMyTimer() {
		return timer;
	}

	public void setMyTimer(MyTimer timer) {
		this.timer = timer;
	}

	public int getSteps() {
		return steps;
	}

	public void setSteps(int steps) {
		this.steps = steps;
	}
	
	public int getBoundRow() {
		return boundRow;
	}

	public void setBoundRow(int boundRow) {
		this.boundRow = boundRow;
	}

	public int getBoundCol() {
		return boundCol;
	}

	public void setBoundCol(int boundCol) {
		this.boundCol = boundCol;
	}
	
	public int getNumOfStars() {
		return numOfStars;
	}

	public void setNumOfStars(int numOfStars) {
		this.numOfStars = numOfStars;
	}

	public InputStream getIs() {
		return is;
	}

	public void setIs(InputStream is) {
		this.is = is;
	}

	public OutputStream getOs() {
		return os;
	}

	public void setOs(OutputStream os) {
		this.os = os;
	}
	
}
