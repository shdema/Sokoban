package controller.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Observable;


public class SokobanServer {
	
	private int port;
	private Handler ch;
	boolean stop;
	
	public SokobanServer(int port) {
		this.port = port;
		this.ch = new Handler();
		this.stop = false;
	}
	
	private void runServer() throws Exception{
			ServerSocket server = new ServerSocket(port);
		
			while (!stop)
			{		
				server.setSoTimeout(1000); //wait 1 second in the accept
				
				try {
					
					Socket aClient = server.accept(); //blocking call - waits for a client to connect
					
					while (aClient.getInetAddress()!=null)
					{
						try 
						{
									ch.handleClient(new BufferedReader(new InputStreamReader(aClient.getInputStream())),
											new PrintWriter(aClient.getOutputStream()));
									
						} catch (IOException e) {System.out.println("IO problem with the client");}
					}
					aClient.getInputStream().close();
					aClient.getOutputStream().close();
					aClient.close();
					
				} catch (SocketTimeoutException e) {System.out.println("Server timeout");}
			}
			
			server.close();
	}
	
	public void start(){
		new Thread(new Runnable() {
			public void run() {
				try{runServer();} catch (Exception e) {}
			}
		}).start();
	}
	
	public void stop(){
		stop = true;
	}

	//gets and sets
	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public Handler getCh() {
		return ch;
	}

	public void setCh(Handler ch) {
		this.ch = ch;
	}
	
}
