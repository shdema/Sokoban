package SolobanSolver;

import java.util.Set;

import commons.SignBoard;
import stripsLib.Action;
import stripsLib.Clause;
import stripsLib.Plannable;
import stripsLib.Predicate;

public class SokobanPlannableAdapter implements Plannable {

	char[][] signB;
	Clause goal;
	Clause kb;
	
	public SokobanPlannableAdapter(SignBoard signboard){
		signB = signboard.getSignBoard();
		goal = new Clause(null);
		kb = new Clause(null);
	}
	
	@Override
	public Clause getGoal(Clause kb) {
		for(Predicate p : kb.getPredicates()){
			if(p.getType().startsWith("star")){
				goal.add(new Predicate("boxAt", "?", p.getValue()));
			}
		}
		return goal;
	}
		

	@Override
	public Clause getKnowledgebase() {
		int boxCount=0;
		int starCount=0;
		for(int i=0;i<signB.length;i++){
			for(int j=0;j<signB[i].length;j++){
				switch(signB[i][j]){
				case '#':kb.add(new Predicate("wallAt", "", i+","+j));break;
				case ' ':kb.add(new Predicate("clearAt", "", i+","+j));break;
				case 'A':kb.add(new Predicate("sokobanAt", "", i+","+j));break;
				case '@':boxCount++;kb.add(new Predicate("boxAt", "b"+boxCount, i+","+j));break;
				case 'o':starCount++;kb.add(new Predicate("starAt", "t"+starCount, i+","+j));break;
				}
			}
		}
		return kb;
	}

	@Override
	public Set<Action> getsatisfyingActions(Predicate top) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Action getsatisfyingAction(Predicate top) {
		// TODO Auto-generated method stub
		return null;
	}

}
