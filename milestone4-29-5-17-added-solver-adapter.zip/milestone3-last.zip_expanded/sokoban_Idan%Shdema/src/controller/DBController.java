package controller;

import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;

import controller.server.SokobanServer;
import model.Model;
import view.DBView;
import view.ScoreboardWindowController;


public class DBController implements Observer {
	private Model model; // reference facade to model
	private DBView scoreView; // 
	private DBView detailsView; //
	private Controller controller; // reference to general Controller class
	private SokobanServer server;
	
	private boolean serverOn = false; // a flag to see if we run on server or locally

	public DBController(Model model, DBView details, DBView score) {
		this.model = model;
		this.scoreView = score;
		this.detailsView = details;
	}

	
	@Override
	public void update(Observable obs, Object arg) {
		@SuppressWarnings("unchecked")
		LinkedList<String> params = (LinkedList<String>) arg; // O(1) solution
		if (obs == model) {
			
			if(params.get(0).equals("scoreList"))
			{
					
				scoreView.setScoreList(model.getScoreList());
				scoreView.updateTable();
			}
//			else if(params.get(0).equals("scoreListUser"))
//			{
//				scoreView.setScoreList(model.getScoreList("User"));
//			}
//			else if(params.get(0).equals("scoreListLevel"))
//			{
//				scoreView.setScoreList(model.getScoreList("Level"));
//			}
		}

		else if (obs == detailsView) { // if view updates the controller
				if ((params.get(0).equals("Details"))) // got user details from view
				{
					model.userDetails(params); // pass model the user details
					model.levelDetails(model.getLevel());
					scoreView.setScoreList(model.getScoreList());
				}
		}
		
		else if (obs == scoreView)
		{
			if(params.get(0).equals("topScoresUser"))
			{
				scoreView.setScoreList(model.getScoreListUser(params.get(1)));
			}
			
			else if(params.get(0).equals("topScoresLevel"))
			{
				scoreView.setScoreList(model.getScoreListLevel(params.get(1)));
			}
			
			else if (params.get(0).equals("mainScores"))
			{
				scoreView.setScoreList(model.getScoreList());
			}
		}
				
//				else if(params.get(0).equals("topScoresUser"))
//				{
//					view.setScoreList(model.getScoreListUser(params.get(1)));
//				}
//				else if(params.get(0).equals("topScoresLevel"))
//				{
//					view.setScoreList(model.getScoreListLevel(params.get(1)));
//				}
//				
//				
//				else if (params.get(0).equals("topScoresUser"))
//				{
//					model.topScoresUser(params.get(1));
//				}
//				else if (params.get(0).equals("topScoresLevel"))
//				{
//					model.topScoresLevel(params.get(1));
//				}

	}
}
