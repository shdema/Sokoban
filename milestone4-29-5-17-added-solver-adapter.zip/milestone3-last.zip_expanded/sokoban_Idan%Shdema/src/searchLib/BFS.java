package searchLib;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class BFS<T> extends CommonSearcher<T> {

	@Override
	public Solution search(Searchable<T> s) {
		Queue<State<T>> openList = new PriorityQueue<>();
		HashSet<State<T>> closeSet = new HashSet<>();
		openList.add(s.getInitialState());
		while (openList.size() > 0) {
			State<T> n = openList.poll();

			closeSet.add(n);
			if (n.equals(s.getGoalState())) {
				return backTrace(n);
			}
			HashMap<Action, State<T>> possibleStatesMap = s.getAllPossibleMoves(n);
			for (Action a : possibleStatesMap.keySet()) {
				State<T> state = possibleStatesMap.get(a);
				if (!openList.contains(state) && !closeSet.contains(state)) {
					state.setCameFrom(n);
					openList.add(state);
				} else {
					if (state.getCost() < n.getCost()) { /// to rewrite!! not
															/// true for sure
						if (!openList.contains(state)) {
							openList.add(state);
						} else {
							/// adjust state priority
							openList.remove(state);
							// set priority state
							openList.add(state);
						}
					}
				}
			}
		}

		return backTrace(s.getGoalState());
	}
}
