package stripsLib;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class CommonPlanner implements Planner {
	
	protected boolean isSatisfied(Predicate p, State state){
		return state.getPredicates().contains(p);
	}
	
	protected Action getSatisfyingAction(Predicate p,List<Action> actions, List<Object> objects){
		for(Action action: actions){
			for(Predicate addP : action.getAddList()){
				if(p.getName().equals(addP.getName())&&p.getArgs().length==addP.getArgs().length){
					Map<String, Object> assignment = findAssignment(p,addP, action, objects);
					if(assignment!=null){
						Action newAction = action.instantiate(assignment);
						return newAction;
					}
				}
			}
		}
	}
	protected Map<String,Object> findAssignment(Predicate p1, Predicate p2, Action action, List<Object> objects){
		Map<String, Object> assignment = new HashMap<>();
		
		Object[] args1 = p1.getArgs();
		Object[] args2 = p2.getArgs();
		Map<String, List<Object>> illegalAssignments = action.getIllegalAssignments();
		for (int i = 0; i < args2.length; i++) {
			if (illegalAssignments.get(args2[i]).contains(args1[i]))
				return null;
			assignment.put((String)args2[i], args1[i]);
		}
		
		//find all unassigned vars (from the action's args)
		for (Object variable : action.getArgs()) {
			if (!assignment.containsKey(variable)) {
				
			}
		}
		
		return assignment;
	}
}
