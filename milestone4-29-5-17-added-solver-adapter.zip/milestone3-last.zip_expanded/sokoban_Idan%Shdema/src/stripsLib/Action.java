package stripsLib;

public class Action extends Predicate{

	protected Clause preconditions,effects;

	public Action(String type, String id, String value) {
		super(type, id, value);
		// TODO Auto-generated constructor stub
	}

	
}
