package stripsLib;

public abstract class CommonPlannable implements Plannable {

}
