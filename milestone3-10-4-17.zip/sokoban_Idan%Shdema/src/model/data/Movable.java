package model.data;

/**
 * Interface for items that can move.
 * @author ����
 *
 */
public interface Movable {
	public void move(String dir);
}
