package model.db;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Manager {
	private static SessionFactory factory;
	private User user;

	public Manager() {
		Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
		Configuration configuration = new Configuration();
		configuration.configure();
		factory = configuration.buildSessionFactory();
	}

	public int addUser(String fName, String lName, int id) {
		user = new User(fName, lName, id);
		Transaction tx = null;
		int userID = 0;
		Session session = factory.openSession();
		try {
			tx = session.beginTransaction();
			userID = (int) session.save(user);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return userID;
	}

	public int addLevel(commons.Level l) {
		Transaction tx = null;
		int levelID = 0;
		Session session = factory.openSession();
		try {
			tx = session.beginTransaction();
			levelID = (Integer) session.save(l);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return levelID;
	}

	// adds the current level to the db
	public int addScore(User user, commons.Level l) {
		Score s = new Score(user.getId(), l.getId(), l.getSteps(), l.getMyTimer().toString());
		Transaction tx = null;
		int scoreID = 0;
		Session userSession = factory.openSession();
		try {
			tx = userSession.beginTransaction();
			scoreID = (Integer) userSession.save(s);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			userSession.close();
		}
		return scoreID;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	// Method to print all employees
	// public void printUsers() {
	// Session session = factory.openSession();
	// try {
	// @SuppressWarnings("unchecked")
	// Query<User> query = session.createQuery("from Users");
	// List<User> list = query.list();
	// for (User e : list) {
	// System.out.println(e);
	// }
	// } catch (HibernateException e) {
	// e.printStackTrace();
	// } finally {
	// session.close();
	// }
	// }

	// Method to print all employees whose names start with specified prefix

	// private static void printEmployeesWhoseNameStartsWith(String prefix) {
	// Session session = factory.openSession();
	// Query query = session.createQuery("from Employees E where E.first_name
	// LIKE :prefix");
	// query.setParameter("prefix", prefix + "%");
	// List<Employee> list = query.list();
	// for (Employee e : list) {
	// System.out.println(e);
	// }
	// session.close();
	// }
	//
	// // Method to update a salary for an employee
	// private static void updateSalary(int empId, double salary) {
	// Session session = factory.openSession();
	// Transaction tx = null;
	// try {
	// tx = session.beginTransaction();
	// Employee emp = session.get(Employee.class, empId);
	// emp.setSalary(salary);
	// session.update(emp);
	// tx.commit();
	// } catch (HibernateException e) {
	// if (tx != null)
	// tx.rollback();
	// e.printStackTrace();
	// } finally {
	// session.close();
	// }
	// }
	//
	// // Method to delete an employee
	// private static void deleteEmployee(int empId) {
	// Session session = factory.openSession();
	// Transaction tx = null;
	// try {
	// tx = session.beginTransaction();
	// Employee emp = session.get(Employee.class, empId);
	// session.delete(emp);
	// tx.commit();
	// } catch (HibernateException e) {
	// if (tx != null)
	// tx.rollback();
	// e.printStackTrace();
	// } finally {
	// session.close();
	// }
	// }
}
