package boot;

public class Run {
	public static void main(String[] args) {
		// Manager mng = new Manager();
		// mng.addUser("Roi", "Yeho", 123);
		// System.out.println("Users list:");
		// mng.printUsers();
		// System.out.println("Employees whose name start with J:");
		// printEmployeesWhoseNameStartsWith("J");
		// System.out.println("Updating salary for employee 1");
		// updateSalary(empID1, 2333.33);
		// System.out.println("Deleting employee 3");
		// deleteEmployee(empID3);
		// System.out.println("Employees list:");
		// printEmployees();
	}
}
