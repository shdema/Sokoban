package view;

import commons.Level;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
/**
 * Facade for the view layer.
 * @author Eon
 *
 */
public interface View {

	public void start();
	public void displayMessage(String msg);
	public void display(Level l);
	public void exit(Level l);
	public void bindTime(StringProperty time);
	public void bindSteps(IntegerProperty steps);
}
