package view;

import java.io.File;

import commons.Level;
import controller.SokobanController;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.MyModel;

/**
 * The main class that runs the game, can run with parameters "-server" and
 * port,<br>
 * to run the game on a server,<br>
 * or if no parameters - runs with GUI.
 * 
 * @author Eon
 *
 */
public class Main extends Application {

	private Stage primaryStage;
	private File keys;
	private MainWindowController view;

	@FXML
	MenuItem Exit;

	@Override
	public void start(Stage primaryStage) {
		this.setPrimaryStage(primaryStage);
		this.keys = new File("./keys.xml");
		try {
			FXMLLoader loader = new FXMLLoader();
			BorderPane root = loader.load(getClass().getResource("MainWindow.fxml").openStream());
			view = loader.getController();
			MyModel model = new MyModel(new Level());
			SokobanController c = new SokobanController(model, view);

			view.setKeyMap(c.mapKeyCodes(keys));

			model.addObserver(c);
			view.addObserver(c);

			Scene scene = new Scene(root, 800, 800);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);

			view.setStage(primaryStage);
			primaryStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void stop() {
		view.exitGame();
	}

	public static void main(String[] args) {
		if (args.length != 0) {
			if (args[0].equals("-server")) {
				MyModel model = new MyModel(new Level());
				SokobanController c = new SokobanController(model, null);
				model.addObserver(c);
				try {
					c.startServer(Integer.parseInt(args[1]));
					c.setView((View) c.getServer().getCh());
					c.getServer().getCh().addObserver(c);
					c.setServerOn();
				} catch (Exception e) {
					// parsing exception
					e.printStackTrace();
				}
			} else
				System.out.println("Check args and run again!");
		} else
			launch(args);
	}

	public Stage getPrimaryStage() {
		return primaryStage;
	}

	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}
}
